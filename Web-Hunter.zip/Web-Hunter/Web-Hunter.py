import subprocess
import xml.etree.ElementTree as ET
import xml.sax.saxutils as xml_utils
import re
import os

# Function to capture the request and save it in a file
def capture_request(url):
    print(f"[INFO] Capturing request for URL: {url}")
    request_data = f"GET {url} HTTP/1.1\nHost: {url}\nUser-Agent: Mozilla/5.0\n"
    with open('captured_request.txt', 'w') as f:
        f.write(request_data)
    print(f"[INFO] Captured request saved to 'captured_request.txt'")

# Function to run wfuzz for XSS scanning and only print working payloads
def run_wfuzz(url):
    print(f"\n{'+'*30}\n|   XSS SCAN RESULTS    |\n{'+'*30}")
    print(f"[INFO] Running wfuzz with XSS payloads on {url}...")
    wfuzz_command = f"wfuzz -c -z file,/usr/share/wfuzz/wordlist/Injections/XSS.txt --hc 404 \"{url}?FUZZ\""
    
    process = subprocess.Popen(wfuzz_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    
    successful_payloads = []
    
    # Load the original XSS payloads to map them later
    with open('/usr/share/wfuzz/wordlist/Injections/XSS.txt', 'r') as payload_file:
        xss_payloads = payload_file.readlines()
    
    for line in process.stdout:
        if "200" in line or "302" in line:  # Filter based on response codes indicating success
            try:
                payload_index = int(line.split(":")[0]) - 1
                original_payload = xss_payloads[payload_index].strip()
                successful_payloads.append(original_payload)
                print(f"[WORKING XSS PAYLOAD] {original_payload}")
            except (IndexError, ValueError):
                continue
    
    process.wait()

    # Save successful XSS payloads to file
    if successful_payloads:
        save_xss_results(successful_payloads)

# Function to save XSS results to an XML file
def save_xss_results(successful_payloads):
    root = ET.Element("XSSResults")
    for payload in successful_payloads:
        entry = ET.SubElement(root, "Payload")
        entry.text = xml_utils.escape(payload)
    
    tree = ET.ElementTree(root)
    tree.write("xss_results.xml")

# Function to run SQLMap for SQL injection detection and only print working payloads
def run_sqlmap(url):
    print(f"\n{'+'*30}\n|   SQL INJECTION SCAN RESULTS   |\n{'+'*30}")
    print(f"[INFO] Running SQLMap for SQL injection on {url}...")

    sqlmap_command = (
        f"sqlmap -u \"{url}\" --batch --level=5 --risk=3 --flush-session --dbs --banner "
        "--tamper=space2comment --random-agent"
    )
    
    process = subprocess.Popen(sqlmap_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    
    successful_sql_injections = []
    
    for line in process.stdout:
        if "SQL injection" in line or "injectable" in line:
            successful_sql_injections.append(line.strip())
            print(f"[WORKING SQL INJECTION PAYLOAD] {line.strip()}")
        elif "heuristic" in line and "might not be injectable" not in line:
            successful_sql_injections.append(line.strip())
            print(f"[WORKING SQL INJECTION PAYLOAD] {line.strip()}")
    
    process.wait()

    # Save successful SQL injections to file
    if successful_sql_injections:
        save_sqlmap_results(successful_sql_injections)

# Function to save SQLMap results to a text file
def save_sqlmap_results(successful_sql_injections):
    root = ET.Element("SQLInjectionResults")
    for result in successful_sql_injections:
        entry = ET.SubElement(root, "Injection")
        entry.text = xml_utils.escape(result)
    
    tree = ET.ElementTree(root)
    tree.write("sqlmap_results.xml")

# Function to run XSRFProbe for CSRF vulnerabilities detection and only print detected vulnerabilities
def run_xsrfprobe(url):
    print(f"\n{'+'*30}\n|   CSRF SCAN RESULTS    |\n{'+'*30}")
    print(f"[INFO] Running XSRFProbe for CSRF vulnerabilities detection on {url}...")

    xsrf_command = f"xsrfprobe -u {url} --crawl"
    
    process = subprocess.Popen(xsrf_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

    raw_output = []
    for line in process.stdout:
        raw_output.append(line.strip())  # Capture the output (do not print)
    
    process.wait()

    # Check if there are any lines in raw_output before proceeding to XML creation
    if not raw_output:
        return

    # Clean up the output by removing non-XML compatible data (ANSI codes, etc.)
    clean_output = []
    ansi_escape = re.compile(r'(?:\x1B[@-_]|[\x0e\x0f\x1b\x9b][0-?]*[ -/]*[@-~])')
    for line in raw_output:
        clean_line = ansi_escape.sub('', line).strip()
        if clean_line:
            clean_output.append(clean_line)

    # Filter and extract detailed information from XSRFProbe output
    important_info = extract_important_info_from_xsrfprobe(clean_output)

    if important_info:
        # Save the detailed information to XML
        save_xsrfprobe_results(important_info)

# Function to extract important information from XSRFProbe raw output
def extract_important_info_from_xsrfprobe(clean_output):
    important_info = []
    for line in clean_output:
        if "VULNERABLE" in line or "No CSRF protection" in line or "form action" in line or "POST-Based" in line:
            important_info.append(line)
            print(f"[WORKING CSRF PAYLOAD] {line}")
    return important_info

# Function to save XSRFProbe results to an XML file
def save_xsrfprobe_results(results):
    root = ET.Element("CSRFResults")
    for result in results:
        entry = ET.SubElement(root, "CSRFVulnerability")
        entry.text = xml_utils.escape(result)
    
    tree = ET.ElementTree(root)
    tree.write("xsrfprobe_results.xml")

# Function to parse the XML results and display them as formatted output
def parse_and_display_results(file_name):
    try:
        tree = ET.parse(file_name)
        root = tree.getroot()

        # Automatically detect the type of scan from the root element
        if file_name == 'xss_results.xml':
            print("\n---- XSS Results ----")
            for payload in root.findall('Payload'):
                print(f"Payload: {payload.text}")
        elif file_name == 'sqlmap_results.xml':
            print("\n---- SQL Injection Results ----")
            for injection in root.findall('Injection'):
                print(f"Injection: {injection.text}")
        elif file_name == 'xsrfprobe_results.xml':
            print("\n---- XSRFProbe CSRF Vulnerability Results ----")
            for result in root.findall('CSRFVulnerability'):
                print(f"Vulnerability: {result.text}")

    except ET.ParseError as e:
        print(f"[ERROR] Failed to parse {file_name}: {e}")
    except FileNotFoundError:
        print(f"[ERROR] {file_name} file not found.")

# Function to handle user's choice
def handle_choice(choice, url):
    if choice == "1":
        run_sqlmap(url)
    elif choice == "2":
        run_wfuzz(url)
    elif choice == "3":
        run_xsrfprobe(url)
    elif choice == "4":
        run_sqlmap(url)
        run_wfuzz(url)
        run_xsrfprobe(url)
        print("[INFO] Exiting the script.")
        exit(0)
    else:
        print("[ERROR] Invalid choice. Please select a valid option.")

def main():

    # Ensure ASCII logo prints correctly without messing up terminal
    print(r"""

 __       __  ________  _______           __    __  __    __  __    __  ________  ________  _______        
/  |  _  /  |/        |/       \         /  |  /  |/  |  /  |/  \  /  |/        |/        |/       \       
$$ | / \ $$ |$$$$$$$$/ $$$$$$$  |        $$ |  $$ |$$ |  $$ |$$  \ $$ |$$$$$$$$/ $$$$$$$$/ $$$$$$$  |      
$$ |/$  \$$ |$$ |__    $$ |__$$ | ______ $$ |__$$ |$$ |  $$ |$$$  \$$ |   $$ |   $$ |__    $$ |__$$ |      
$$ /$$$  $$ |$$    |   $$    $$< /      |$$    $$ |$$ |  $$ |$$$$  $$ |   $$ |   $$    |   $$    $$<       
$$ $$/$$ $$ |$$$$$/    $$$$$$$  |$$$$$$/ $$$$$$$$ |$$ |  $$ |$$ $$ $$ |   $$ |   $$$$$/    $$$$$$$  |      
$$$$/  $$$$ |$$ |_____ $$ |__$$ |        $$ |  $$ |$$ \__$$ |$$ |$$$$ |   $$ |   $$ |_____ $$ |  $$ |      
$$$/    $$$ |$$       |$$    $$/         $$ |  $$ |$$    $$/ $$ | $$$ |   $$ |   $$       |$$ |  $$ |      
$$/      $$/ $$$$$$$$/ $$$$$$$/          $$/   $$/  $$$$$$/  $$/   $$/    $$/    $$$$$$$$/ $$/   $$/       
                                                                                                           
                                                                                                           
                                                                                                             
                                                                           
                                                                           
                                                                           
    """)

    url = input("Enter the URL to scan: ")

    while True:
        print("\nChoose the scan you want to perform:")
        print("1 - SQL Injection Scan")
        print("2 - XSS Scan")
        print("3 - CSRF Scan")
        print("4 - Perform All Scans")
        print("5 - Exit")
        choice = input("Enter your choice: ")

        handle_choice(choice, url)

if __name__ == "__main__":
    main()
